# Validation and limits

The browser target is Firefox 158.0 on macOS. Browser checks were performed only in a disposable test profile. Normal browsing profiles and the Zen installation were not used. This record describes targeted checks, not a guarantee for every Firefox version, theme, platform, or extension.

## Browser checks

- Native vertical tabs, groups, pinned tabs, collapsed rail, split panes, and native menus were exercised.
- The Favorites/Pinned/Today hierarchy was checked in a disposable window: three priority tiers, a responsive Favorite grid, compact full-width rows, native/visual ordering after reordering, a real tab context menu and its priority command, native unpin clearing the Favorite marker, serialized-and-restored Favorite session data, script reload, the 52px collapsed rail, and preservation of native split alignment. See [the hierarchy report](TAB-HIERARCHY.md) and [fixture measurements](validation/tab-hierarchy.json).
- The revised layout has one Clear divider, New Tab directly below it, and no Today heading. A real Clear click preserved the Favorite/folder and closed ordinary tabs; native undo restored them. Additional cases protected native pins/hidden tabs, closed an ordinary split pair, retained the last-tab window, and verified collapsed/reload/unload behavior. See [current measurements](validation/clear-layout.json).
- Trusted pointer dragging resized the expanded sidebar from 173px to 263px to 203px. Collapse used the 52px rail; re-expansion retained the native width. The original width was restored.
- The sidebar container, launcher, frame image, selected-tab background, and selected text were compared directly against native styling in four theme cases: built-in default, custom light, custom dark, and an image theme omitting sidebar colors. All matched; the selected tab keeps the Zen-style border treatment but uses the exact native fill. The custom layout was temporarily gated off in the fixture to obtain the native baseline.
- Folder icons were checked in 24 combinations of theme, blue/red/green group palette, and open/closed state. Each opaque icon matched its native group color, each name matched native sidebar text, and changing blue to purple updated the icon immediately. A faint theme-ink edge supports visibility; forced-colors mode uses CanvasText. See [theme details](THEMES.md) and [measurements](validation/native-theme-colors.json).
- Native split pairs retained equal, horizontally aligned headers and actual side-by-side page panes. Header divider borders have zero width with 173px and 280px sidebars, for active and inactive splits, with and without the hierarchy script (eight cases). See [measurements](validation/split-borders.json). The selected-tab outline remained visible.
- Empty-sidebar window-drag rules and interactive-element exclusions matched parsed chrome CSS rules. Physical macOS window movement was not certified by that check.
- Floating New Tab search was tested with real keyboard/button input: opening/canceling retained the current page and tab count, submission created a tab, and tab switching canceled the overlay. Native search/address handling was retained.
- Drag-to-split used native tab dragging and native split panes. Completing native drag cleanup before grouping prevents a retained tab translation from misaligning the headers.
- The floating Compact Mode toolbar inherited the native frame background in four themes. A sampled toolbar region remained pixel-identical when its fixture page changed from white to black; theme background colors and images matched the window body. See [measurements](validation/opaque-toolbar.json) and [fixture preview](images/opaque-toolbar.png).
- Both floating surfaces were checked together across four themes, expanded/collapsed sidebars, and docked/floating top bars (16 cases). Sidebar and toolbar sample pixels stayed identical over white and black fixture pages; the sidebar color/image matched the native window body. A test-only hover lock held the sidebar open to isolate paint, so this check does not certify physical edge-hover behavior. See [measurements](validation/opaque-sidebar.json) and [preview](images/opaque-sidebar.png).
- Coordinated Compact Mode was exercised with trusted pointer/keyboard input, without hover locks: either edge reveals both bars; crossing the shared corner preserves the sidebar inset and page geometry; tab clicks, tab context menus, and the application menu remain usable. Controls stay painted during the hide grace period. Command+L and floating New Tab search reveal both bars from hidden. The optional controls hook measured 44px, 72px with bookmarks, and 84px with enlarged bookmarks; script reload/unload restored the height property. Collapsed-rail, CSS-only handoff, and each independent preference combination were checked. See [interaction measurements](validation/compact-interaction.json) and [preview](images/compact-interaction.png).
- Compact Mode was checked across toolbar/sidebar visibility combinations. Real Control+Z presses toggled both flags without collapsing the native sidebar. Recording, saving, conflict rejection, reset, no-shortcut, reload, and uninstall behavior were checked. Selecting a different binding restored native Control+Z behavior.
- The startup loader was exercised in an existing window and through a new-window startup event. **Loading through application AutoConfig after a full quit/relaunch remains unverified.**
- Cleanup checks with disposable, artificially aged local test tabs closed the eligible ordinary tab and preserved pinned, grouped, selected, and recent tabs. Undo reopened the closed test page. A real unattended 24-hour run and all crash/event races remain unverified.

Temporary themes/tabs were removed and user settings restored after focused checks. Browser evidence containing local paths or browsing details is not distributed. The included split-header preview contains only two disposable local fixture tabs.

## Final bug audit

48 automated tests pass: 23 installer tests and 25 cleanup/popup tests. The final isolated-profile browser run passed all four Compact Mode layouts, saved/canceled controls, independent edge reveals, search-mode restoration, URL submission, folder teardown, scrolling with 104 tabs, deferred reordering during a drag, and both split-drop directions with aligned headers and no stale overlay. No window errors were captured. See [browser results](validation/audit-ui.json) and [focused edge cases](validation/audit-edges.json).

Fixed grouped tabs remaining grouped after choosing Today, repeated hierarchy work on title changes, closed-folder references, selected tabs falling outside the scroller after folder reordering, canceled search losing its mode, stale split targets, hidden-tab cleanup, misleading recovery after a blocked close, repeated popup actions, and failed-install/uninstall retry handling. Compact settings now expose each visibility mode and independent/shared reveals.

Application AutoConfig cold-start, physical macOS window dragging, other Firefox versions/platforms, and a real unattended 24-hour cleanup run remain unverified. The cleanup download remains unsigned.

## Performance changes

Hierarchy updates now share work within a display frame, reuse one tab snapshot and one Favorite lookup per pin, and avoid rescanning tabs on sidebar resizing. Drag preview styles update when the pointer changes halves, rather than on every drag event. The cleanup extension filters unrelated updates before delivery, reuses its saved activity map after event-page suspension, and skips timestamp reads for already-protected tabs. Protection, recovery, and five-minute scheduling remain unchanged. [Measurements and limits](PERFORMANCE.md); [browser regression results](validation/performance-regression.json).

## Minimal-build recheck

The idle-footprint changes were checked again with native Firefox controls in disposable windows. The recheck includes dialog/search/drag lifetimes, immediate dialog reopen, shortcut recording/save/conflict/disable/reload, native sidebar resizing/collapse, all Compact Mode layouts and shared-corner/menu interactions, floating search submission/cancellation/search modes, tab priorities/folders/Clear, 104-tab scrolling, deferred drag reordering, both split-drop directions, four native theme cases and 24 folder states, and 16 floating opacity cases. No script errors were captured by the UI/lifecycle fixtures.

Native video playback, Picture-in-Picture, content fullscreen and its New Tab exit, restored page corners, find-in-page, a downloaded-and-removed local fixture file, the cleanup popup, and reduced motion passed. The loader also loaded all four hooks once in both an existing window and a new delayed-startup window, with no prebuilt settings dialog. This remains an in-process loader lifecycle test, not an application AutoConfig cold-start test.

The pass fixed an immediate-reopen race in the new transient dialog and verified cleanup has no scheduled alarm while paused. Original profile windows, settings, theme, and toolbar placement were preserved. [Source hashes and recheck reports](validation/minimal-audit.json).

## Automated checks

The repository includes 80 automated tests: 25 cleanup policy, recovery, event-page, and popup tests, 41 installer/update tests, and 14 floating-search lifecycle tests. Installer cases use temporary filesystem fixtures and cover backup/restore, explicit closed-browser confirmation, previews without writes, conflicts, version checking, symlink rejection, edited-file preservation, shared loader retention, write-failure rollback, an exact previous-loader upgrade with backup, rejection of a modified loader, atomic writes, failed-install retries, recoverable uninstall failures, and guided source setup/restore/update/cancellation with Finder paths. The guided wizard was checked with temporary filesystem fixtures; a quarantined-download launch and the application AutoConfig cold-start remain unverified.

See [DEVELOPMENT.md](DEVELOPMENT.md) to run these checks and rebuild downloads. No real profile or application installation occurs during the automated tests.

## Floating-search focus and wake recovery

The old hook canceled the floating New Tab search when macOS returned focus to the page. Recovery now preserves the draft, native search mode, and selection through temporary window blur/deactivation, minimize/restore, and sleep/process-resume notifications. macOS can blur/refocus a window without a matching deactivate/activate pair; the native reproduction covered that path.

Six real two-window focus cycles and native minimize/restore retained a bookmark-search draft and backward text selection. Twenty simulated sleep/wake cycles called only this hook's observer, avoiding global browser or OS sleep effects. Recovery did not focus a background window. Escape, Command+L, an outside pointer event, tab switching, navigation, and uninstall canceled pending restoration; submission after recovery created exactly one new tab and preserved the source page. Thirty lifecycle cycles returned to two idle listeners and zero power observers; uninstall removed every hook. No window errors were captured. [Recorded results and source hash](validation/search-wake.json).

The 14 new automated cases cover these races, coalesced wake signals, synchronous focus during native view teardown, process resume, and cleanup. **Physical operating-system sleep was not forced**, so these checks do not certify every hardware wake sequence. The existing UI regression was rerun against the changed hook, including search-mode restoration, settings, hierarchy, large-tab scrolling, and both split-drop directions.

## Managed updates

Fourteen update tests cover preserved settings/custom CSS/application files, original uninstall backups, old-entry migration, edited managed-file protection, missing-file repair, no-write previews and up-to-date checks, failed-write/state-commit rollback and retry, unexpected paths/symlinks/untracked collisions, and guided update/cancellation without an application target. The updater runs only on demand and changes profile files; it does not add browser listeners, background checks, or a service. Installer/update checks use disposable filesystem fixtures, not a live browsing profile or real application bundle. The full application AutoConfig cold-start limitation remains unchanged.

A packaged integration check installed the previously shipped archive into filesystem fixtures, ran the new archive's guided update, confirmed current CSS/scripts and preserved settings/custom CSS/application files, reran it without writes, then restored the pre-ZenFX originals with uninstall. All packaged source hashes matched. The source wizard and CLI were exercised; the optional Tk update button was not. [Results](validation/managed-update.json).

## Native session restoration

Setup and updates now enable `browser.startup.page = 3` in a separate managed `user.js` block. Four new automated cases cover initial setup, migration with later user edits retained through uninstall, idempotence/privacy-setting preservation, and rollback after a failed state commit. Unrelated preferences, session files, and privacy settings are not changed by the installer.

A real clean process quit and relaunch in the authorized Firefox 158/macOS test profile restored all seven fixture tabs: a Favorite, a pin, two grouped tabs with the same name/color, an ordinary selected tab, and both native Split View tabs. Four background tabs remained pending rather than eagerly loaded. The original test window also returned. The fixture window was removed afterward. [Native restart results](validation/session-restore.json).

The Favorite marker and native session metadata were checked before explicitly loading the interface hooks; all seven priority tiers were correct after loading them. This verifies native session persistence, not application AutoConfig cold-start hook loading. Private browsing, clearing browsing history on exit, deliberately closed tabs, corrupt/discarded session data, crashes, and OS-reboot recovery are outside this clean-restart check. Normal browsing profiles and application files were not modified.
